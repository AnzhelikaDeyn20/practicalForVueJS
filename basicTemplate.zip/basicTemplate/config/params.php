<?php

return [
    'adminEmail' => 'admin@example.com',
    'user.passwordResetTokenHash' => 3600
];
