<?php

namespace app\controller;

use yii\web\Controller;
use yii\web\models\Orders;
use yii\web\data\Pagination;

class OrdersController extends Controller
{
	public function actionIndex() {
		$query = Orders::find();
		$pagination = new Pagination(['defaultPageSize'=>1, 'totalCount'=>$query->count()]);
		$orders  = $query->orderBy('descript')-> offset($pagination->offset)->limit($pagination->limit)->all();
		return $this->render('index',  [
			'orders' => $orders,
			'pagination' => $pagination
		]);

	}
}

