<?php

namespace app\controllers;

use yii\web\Controller;
use app\models\Orders;
use yii\data\Pagination;

class OrdersController extends Controller
{
	public function actionIndex() {
		$query = Orders::find();
		$pagination = new Pagination(['defaultPageSize'=>2, 'totalCount'=>$query->count()]);
		$orders  = $query->orderBy('descript')-> offset($pagination->offset)->limit($pagination->limit)->all();
		return $this->render('index',  [
			'orders' => $orders,
			'pagination' => $pagination
		]);

	}
}

