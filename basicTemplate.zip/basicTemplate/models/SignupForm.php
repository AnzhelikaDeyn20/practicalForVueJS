<?php

namespace app\models;

use yii\base\Model;
use app\models\User;

/**
* 
*/
class SignupForm extends Model
{
	public $username;
	public $email;
	public $password;
	public $passwordConfirm;
	public $phone;
	//public $id;
	public function rules()
	{
		return [
			[['username', 'email', 'password', 'passwordConfirm'], 'required'],
			[['username', 'email'], 'trim'],
			['username', 'unique', 'targetClass' => 'app\models\User', 'message' => 'Такое имя пользователя уже существует'],
			['email', 'email'],
			['email', 'unique', 'targetClass' => 'app\models\User', 'message' => 'Этот email уже занят'],
			['password', 'match', 'pattern' => '/(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[A-Z]{2})(?=.*\W{2})/'],
			['passwordConfirm', 'compare', 'compareAttribute' => 'password'],
			['phone', 'match', 'pattern' => '/[0-9]/'],
			['phone', 'string', 'min' => 5, 'max' => 9]
		];
	}
	public function signup()
	{


		$user = new User();
		$user->username = $this->username;
		//$user->id=1;
		$user->email = $this->email;
		$user->phone = $this->phone;
		$user->setPassword($this->password);
		$user->generateAuthKey();
		return $user->save() ? $user : null;
	}
}