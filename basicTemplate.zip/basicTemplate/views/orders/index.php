<?php

use yii\helpers\Html;
use yii\widgets\LinkPager;

?>

<h2>Товары</h2>
<ul>

	<?php
	foreach ($orders as $order):
	?>

	<li>
		<?=
			Html::encode("$order->descript $order->name ");
		?> <?= $order->id ?>
	</li>
	<?php
		endforeach;
	?>
</ul>
<?= LinkPager::widget([
		'pagination'=>$pagination
	]);
?>