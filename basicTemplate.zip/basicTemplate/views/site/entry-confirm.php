<?php

/* @var $this yii\web\View */
use yii\helpers\Html

?>

<h1>Информация о пользователе</h1>

<ul>
	<li>Логин</li><?= Html::encode($model->login) ?>
	<li>E-mail</li><?= Html::encode($model->email) ?>
</ul>