<?php

/* @var $this yii\web\View */
use yii\helpers\Html;
use yii\widgets\ActiveForm;

$form = ActiveForm::begin()

?>

<?= $form->field($model, 'login'); ?>
<?= $form->field($model, 'email'); ?>

<div class="form-group">
	<?= 
		Html::submitButton('Poehali', [
			'class' => 'btn btn-primary'
		]); 
	?>
</div>
<?php
ActiveForm::end();
?>