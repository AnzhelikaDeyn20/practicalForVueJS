<?php

/* @var $this yii\web\View */
use yii\helpers\Html

?>
<?= Html::encode($msg); ?>
