<?php

/* @var $this yii\web\View */

$this->title = 'My Yii Application';
?>
<div class="ubea-loader"></div>
    
    <div id="page">
    <div id="ubea-hero" class="js-fullheight"  data-section="home">
        <div class="flexslider js-fullheight">
            <ul class="slides">
            <li style="background-image: url(images/img_bg_1.jpg);">
                <div class="overlay"></div>
                <div class="container">
                    <div class="col-md-10 col-md-offset-1 text-center js-fullheight slider-text">
                        <div class="slider-text-inner">
                            <h2>Explore the new template.</h2>
                            <p><a href="http://twitter.com/freshdesignweb" target="_blank" class="btn btn-primary btn-lg">Follow @freshdesignweb</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li style="background-image: url(images/img_bg_2.jpg);">
                <div class="overlay"></div>
                <div class="container">
                    <div class="col-md-10 col-md-offset-1 text-center js-fullheight slider-text">
                        <div class="slider-text-inner">
                            <h2>Creative. Innovative.Intuitive.</h2>
                            <p><a href="#" class="btn btn-primary btn-lg">Get started</a></p>
                        </div>
                    </div>
                </div>
            </li>
            <li style="background-image: url(images/img_bg_3.jpg);">
                <div class="overlay"></div>
                <div class="container">
                    <div class="col-md-10 col-md-offset-1 text-center js-fullheight slider-text">
                        <div class="slider-text-inner">
                            <h2>A new experience.</h2>
                            <p><a href="#" class="btn btn-primary btn-lg">Get started</a></p>
                        </div>
                    </div>
                </div>
            </li>
            </ul>
        </div>
    </div>

    <div class="ubea-section-overflow">

        <div class="ubea-section" id="ubea-services" data-section="services">
            <div class="ubea-container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="ubea-heading">
                            <h2 class="ubea-left">Services</h2>
                            <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="row">

                            <div class="col-md-12">
                                <div class="feature-left">
                                    <span class="icon">
                                        <i class="icon-umbrella"></i>
                                    </span>
                                    <div class="feature-copy">
                                        <h3>Wealth Management</h3>
                                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Nulla cursus pharetra massa at lacinia Fusce eleifhend Fusce in dapibus.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="feature-left">
                                    <span class="icon">
                                        <i class="icon-monitor"></i>
                                    </span>
                                    <div class="feature-copy">
                                        <h3>Investment Banking</h3>
                                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Nulla cursus pharetra massa at lacinia Fusce eleifhend Fusce in dapibus.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="feature-left">
                                    <span class="icon">
                                        <i class="icon-cup"></i>
                                    </span>
                                    <div class="feature-copy">
                                        <h3>Sales and Trading</h3>
                                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Nulla cursus pharetra massa at lacinia Fusce eleifhend Fusce in dapibus.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 animate-box" data-animate-effect="fadeIn">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="feature-left">
                                    <span class="icon">
                                        <i class="icon-pencil"></i>
                                    </span>
                                    <div class="feature-copy">
                                        <h3>Strategic Planning</h3>
                                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Nulla cursus pharetra massa at lacinia Fusce eleifhend Fusce in dapibus.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="feature-left">
                                    <span class="icon">
                                        <i class="icon-cog"></i>
                                    </span>
                                    <div class="feature-copy">
                                        <h3>Turnaround Consulting</h3>
                                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Nulla cursus pharetra massa at lacinia Fusce eleifhend Fusce in dapibus.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="feature-left">
                                    <span class="icon">
                                        <i class="icon-layers"></i>
                                    </span>
                                    <div class="feature-copy">
                                        <h3>Bonds & Commodities</h3>
                                        <p>Lorem ipsum dolor sit amet consectetur adipiscing elit. Nulla cursus pharetra massa at lacinia Fusce eleifhend Fusce in dapibus.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="ubea-section" id="ubea-portfolio" data-section="portfolio">
            <div class="ubea-container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center ubea-heading">
                        <h2>Portfolio</h2>
                        <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <a href="images/img_2.jpg" class="ubea-card-item image-popup" title="Project name here.">
                            <figure>
                                <div class="overlay"><i class="ti-plus"></i></div>
                                <img src="images/img_2.jpg" alt="Image" class="img-responsive">
                            </figure>
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="images/img_1.jpg" class="ubea-card-item image-popup" title="Project name here.">
                            <figure>
                                <div class="overlay"><i class="ti-plus"></i></div>
                                <img src="images/img_1.jpg" alt="Image" class="img-responsive">
                            </figure>
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="images/img_3.jpg" class="ubea-card-item image-popup" title="Project name here.">
                            <figure>
                                <div class="overlay"><i class="ti-plus"></i></div>
                                <img src="images/img_3.jpg" alt="Image" class="img-responsive">
                            </figure>
                        </a>
                    </div>

                    <div class="col-md-4">
                        <a href="images/img_4.jpg" class="ubea-card-item image-popup" title="Project name here.">
                            <figure>
                                <div class="overlay"><i class="ti-plus"></i></div>
                                <img src="images/img_4.jpg" alt="Image" class="img-responsive">
                            </figure>
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="images/img_5.jpg" class="ubea-card-item image-popup" title="Project name here.">
                            <figure>
                                <div class="overlay"><i class="ti-plus"></i></div>
                                <img src="images/img_5.jpg" alt="Image" class="img-responsive">
                            </figure>
                        </a>
                    </div>
                    <div class="col-md-4">
                        <a href="images/img_6.jpg" class="ubea-card-item image-popup" title="Project name here.">
                            <figure>
                                <div class="overlay"><i class="ti-plus"></i></div>
                                <img src="images/img_6.jpg" alt="Image" class="img-responsive">
                            </figure>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="ubea-section" id="ubea-faq" data-section="faq">
            <div class="ubea-container">
                <div class="row">
                    <div class="col-md-8 col-md-offset-2 text-center ubea-heading">
                        <h2>Frequently Ask Questions</h2>
                        <p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">

                        <div class="ubea-accordion">
                            <div class="ubea-accordion-heading">
                                <div class="icon"><i class="icon-cross"></i></div>
                                <h3>What is uBeasa?</h3>
                            </div>
                            <div class="ubea-accordion-content">
                                <div class="inner">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non sed sequi rerumar quasi repellat eum earum praesentium totam! Quia, voluptas eaque anim uis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore pariatur.</p>
                                </div>
                            </div>
                        </div>
                        <div class="ubea-accordion">
                            <div class="ubea-accordion-heading">
                                <div class="icon"><i class="icon-cross"></i></div>
                                <h3>I have technical problem, who do I email?</h3>
                            </div>
                            <div class="ubea-accordion-content">
                                <div class="inner">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non sed sequi rerumar quasi repellat eum earum praesentium totam! Quia, voluptas eaque anim uis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore pariatur. </p>
                                </div>
                            </div>
                        </div>
                        <div class="ubea-accordion">
                            <div class="ubea-accordion-heading">
                                <div class="icon"><i class="icon-cross"></i></div>
                                <h3>How do I use uBeasa features?</h3>
                            </div>
                            <div class="ubea-accordion-content">
                                <div class="inner">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non sed sequi rerumar quasi repellat eum earum praesentium totam! Quia, voluptas eaque anim uis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore pariatur.</p>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">

                        <div class="ubea-accordion">
                            <div class="ubea-accordion-heading">
                                <div class="icon"><i class="icon-cross"></i></div>
                                <h3>What language are available?</h3>
                            </div>
                            <div class="ubea-accordion-content">
                                <div class="inner">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non sed sequi rerumar quasi repellat eum earum praesentium totam! Quia, voluptas eaque anim uis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore pariatur. </p>
                                </div>
                            </div>
                        </div>
                        <div class="ubea-accordion">
                            <div class="ubea-accordion-heading">
                                <div class="icon"><i class="icon-cross"></i></div>
                                <h3>Can I have a username that is already taken?</h3>
                            </div>
                            <div class="ubea-accordion-content">
                                <div class="inner">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non sed sequi rerumar quasi repellat eum earum praesentium totam! Quia, voluptas eaque anim uis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore pariatur. </p>
                                </div>
                            </div>
                        </div>
                        <div class="ubea-accordion">
                            <div class="ubea-accordion-heading">
                                <div class="icon"><i class="icon-cross"></i></div>
                                <h3>Is uBeasa free?</h3>
                            </div>
                            <div class="ubea-accordion-content">
                                <div class="inner">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non sed sequi rerumar quasi repellat eum earum praesentium totam! Quia, voluptas eaque anim uis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore pariatur. </p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>

    </div>
    
    <div id="ubea-blog" data-section="about">
        <div class="ubea-container">
            <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center ubea-heading">
                    <h2>About us</h2>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Non sed sequi rerumar quasi repellat eum earum praesentium totam! Quia, voluptas eaque anim uis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore pariatur. </p>
                </div>
            </div>
        </div>
    </div>
      
    <div id="ubea-contact" data-section="contact" class="ubea-cover ubea-cover-xs" style="background-image:url(images/img_bg_2.jpg);">
        <div class="overlay"></div>
        <div class="ubea-container">
            <div class="row text-center">
                <div class="display-t">
                    <div class="display-tc">
                        <div class="col-md-12">
                            <h3>If you have inqueries please email us at <a href="#">info@yourdomain.com</a></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer id="ubea-footer" role="contentinfo">
        <div class="ubea-container">
            
            <div class="row copyright">
                <div class="col-md-12">
                    <p class="pull-left">
                        <small class="block">&copy; 2018 freshDesignweb. All Rights Reserved.</small> 
                        <small class="block">Designed by <a href="https://www.freshdesignweb.com/" target="_blank">freshDesignweb.com</a></small>
                    </p>
                    <p class="pull-right">
                        <ul class="ubea-social-icons pull-right">
                            <li><a href="#"><i class="icon-twitter"></i></a></li>
                            <li><a href="#"><i class="icon-facebook"></i></a></li>
                            <li><a href="#"><i class="icon-linkedin"></i></a></li>
                            <li><a href="#"><i class="icon-dribbble"></i></a></li>
                        </ul>
                    </p>
                </div>
            </div>

        </div>
    </footer>
    </div>

    <div class="gototop js-top">
        <a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
    </div>
